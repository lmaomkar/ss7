a =  612203037
print(a%20)